package dev.mvgioser.pc1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etTalla: EditText = findViewById(R.id.etTalla)
        val etPeso: EditText = findViewById(R.id.etPeso)
        val tvR: TextView = findViewById(R.id.tvR)
        val tvR2: TextView = findViewById(R.id.tvR2)
        val btnCalcular: Button = findViewById(R.id.btnCalcular)

        btnCalcular.setOnClickListener {
            tvR.setText(
                " "+(etPeso.text.toString().toDouble()/(etTalla.text.toString().toDouble()*etTalla.text.toString().toDouble()/10000).toDouble())
            )
            tvR2.setText(
                " "+(etPeso.text.toString().toDouble()/(etTalla.text.toString().toDouble()*etTalla.text.toString().toDouble()/10000).toDouble())
            )
            this.sendMessage(tvR.text.toString())
            this.sendMessage(tvR2.text.toString())

        }


        }

        private fun sendMessage(message: String)
        {
            val intent = Intent(this, ResultActivity::class.java)
            intent.putExtra("param",message)
            startActivity(intent)
        }
    }